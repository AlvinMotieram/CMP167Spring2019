/* 
 * file : Quadratic.java
 * author: Alvin Motieram
 * created: 2.14.19
 * desc: This program implements quadratic formula
*/
import java.util.Scanner;
public class Quadratic {
	public static void main (String [] args) {
		
		System.out.println("Welcome to Quadratic Calculator");
		System.out.println("This program implements quadratic formula");
		
		Scanner input = new Scanner(System.in);
		
		double root1, root2;
		double a, b, c;
		double discriminant;
		
		System.out.println("Enter a: ");
		a = input.nextDouble();
		System.out.println("Enter b: ");
		b = input.nextDouble();
		System.out.println("Enter c: ");
		c = input.nextDouble();
		
		discriminant = b*b - 4*a*c;
		
		root1 = (-b + Math.sqrt(discriminant))/(2*a);
		root2 = (-b - Math.sqrt(discriminant))/(2*a);
		
		System.out.println("TThe root 1 is" + root1 +
				"The root 2 is" + root2);
	}

}
