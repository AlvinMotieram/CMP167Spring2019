import java.util.Scanner; 

public class Agetitle {
	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		int userAge;
		String ageType;
		
		System.out.print("Enter age: ");
		userAge = scnr.nextInt();
		
		if (userAge > 25) {
			System.out.println("Adult");
		}
		else if (userAge >= 19 && userAge <= 25) {
			System.out.println("Young adult");
		}
		else if (userAge < 19) {
			System.out.println("teen");
		}
		
		
	}
	

}
